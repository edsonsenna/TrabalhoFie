function carregar(){
	
	var xmlHttp = new XMLHttpRequest();
	
	xmlHttp.onreadystatechange = function(){
		if(xmlHttp.readyState == 4 & xmlHttp.status == 200){
			xmlDoc = xmlHttp.responseXML;
			
			cursos = xmlDoc.getElementsByTagName("Curso");
			
			var selectCursos = 	document.getElementById("txtCursos");
			
			for( i = 0; i < cursos.length; i++){
				var option = document.createElement("option");
				option.value = cursos[i].getElementsByTagName("Codigo")[0].childNodes[0].nodeValue;
				option.text = cursos[i].getElementsByTagName("Nome")[0].childNodes[0].nodeValue;
				selectCursos.add(option);
			}
		}
		
	}
	
	xmlHttp.open("GET", "cursos.xml", true);
	xmlHttp.send();
}