<?php
header("Content-type: text/json");
?>
[
	{
		"codigo" : "1",
		"nome" : "Administração"
	},
	{
		"codigo" : "2",
		"nome" : "Moda"
	},
	{
		"codigo" : "3",
		"nome" : "Ciência da Computação"
	}
]