function carregar(){
	
	var xmlHttp = new XMLHttpRequest();
	
	xmlHttp.onreadystatechange = function(){
		if(xmlHttp.readyState == 4 & xmlHttp.status == 200){
		
			var array = JSON.parse(xmlHttp.responseText);
			
			var selectCursos = 	document.getElementById("txtCursos");
			
			var length = selectCursos.options.length;
			
			var i;
			
			for(i = selectCursos.options.length - 1; i>=0 ; i--){
				selectCursos.remove(i);
			}
			
			for( i = 0; i < array.length; i++){
				var option = document.createElement("option");
				option.value = array[i].codigo;
				option.text = array[i].nome;
				selectCursos.add(option);
			}
		}
		
	}
	
	xmlHttp.open("GET", "cursos.php", true);
	xmlHttp.send();
}