function carregarMarcas(){
	
	var xmlHttp = new XMLHttpRequest();
	
	xmlHttp.onreadystatechange = function(){
		if(xmlHttp.readyState == 4 & xmlHttp.status == 200){
		
			var array = JSON.parse(xmlHttp.responseText);
			
			var selectMarcas = 	document.getElementById("txtMarcas");
			
			var length = selectMarcas.options.length;
			
			var i;
			
			for(i = selectMarcas.options.length - 1; i>=0 ; i--){
				selectMarcas.remove(i);
			}
			
			for( i = 0; i < array.length; i++){
				var option = document.createElement("option");
				option.value = array[i].id;
				option.text = array[i].name;
				selectMarcas.add(option);
			}
		}
		
	}
	
	xmlHttp.open("GET", "http://fipeapi.appspot.com/api/1/carros/marcas.json", true);
	xmlHttp.send();
}

function carregarVeiculos(){
	
	var xmlHttp = new XMLHttpRequest();
	
	xmlHttp.onreadystatechange = function(){
		if(xmlHttp.readyState == 4 & xmlHttp.status == 200){
			
			
			var array = JSON.parse(xmlHttp.responseText);
			
			var selectVeiculos = 	document.getElementById("txtVeiculos");
			
			var length = selectVeiculos.options.length;
			
			var i;
			
			for(i = selectVeiculos.options.length - 1; i>=0 ; i--){
				selectVeiculos.remove(i);
			}
			
			for( i = 0; i < array.length; i++){
				var option = document.createElement("option");
				option.value = array[i].id;
				option.text = array[i].name;
				selectVeiculos.add(option);
			}
		}
		
	}
	var e = document.getElementById("txtMarcas");
	var selected = e.options[e.selectedIndex].value;
	xmlHttp.open("GET", "http://fipeapi.appspot.com/api/1/carros/veiculos/"+selected+".json", true);
	xmlHttp.send();
}

function carregarModelos(){
	
	var xmlHttp = new XMLHttpRequest();
	
	xmlHttp.onreadystatechange = function(){
		if(xmlHttp.readyState == 4 & xmlHttp.status == 200){
			
			
			var array = JSON.parse(xmlHttp.responseText);
			
			var selectModelos = document.getElementById("txtModelos");
			
			var length = selectModelos.options.length;
			
			var i;
			
			for(i = selectModelos.options.length - 1; i>=0 ; i--){
				selectModelos.remove(i);
			}
			
			for( i = 0; i < array.length; i++){
				var option = document.createElement("option");
				option.value = array[i].id;
				option.text = array[i].name;
				selectModelos.add(option);
			}
		}
		
	}
	var e = document.getElementById("txtVeiculos");
	var selected = e.options[e.selectedIndex].value;
	var f = document.getElementById("txtMarcas");
	var selected1 = f.options[f.selectedIndex].value;
	xmlHttp.open("GET", "http://fipeapi.appspot.com/api/1/carros/veiculos/"+selected1+"/"+selected+".json", true);
	xmlHttp.send();
}