<?php
sleep(2);
?>

<select name="frutas" id="frutas">
	<option value="1">Maçã</option>
	<option value="2">Laranja</option>
	<option value="3">Uva</option>
	<option value="4">Abacaxi</option>
</select>