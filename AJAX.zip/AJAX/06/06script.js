function carregar(){
	
	var xmlHttp = new XMLHttpRequest();
	
	xmlHttp.onreadystatechange = function(){
		if(xmlHttp.readyState == 4 & xmlHttp.status == 200){
		
			parser = new DOMParser();
			
			xmlDoc = parser.parseFromString(xmlHttp.responseText, "text/xml");
			
			cursos = xmlDoc.getElementsByTagName("Curso");
			
			var selectCursos = 	document.getElementById("txtCursos");
			
			var length = selectCursos.options.length;
			
			var i;
			
			for(i = selectCursos.options.length - 1; i>=0 ; i--){
				selectCursos.remove(i);
			}
			
			for( i = 0; i < cursos.length; i++){
				var option = document.createElement("option");
				option.value = cursos[i].getElementsByTagName("Codigo")[0].childNodes[0].nodeValue;
				option.text = cursos[i].getElementsByTagName("Nome")[0].childNodes[0].nodeValue;
				selectCursos.add(option);
			}
		}
		
	}
	
	xmlHttp.open("GET", "cursos.php", true);
	xmlHttp.send();
}