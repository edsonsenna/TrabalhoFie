<?php
header("Content-type: text/xml");
$_codigo = isset($_GET["Codigo"]) ? $_GET["Codigo"] : -1;
?>
<?xml version="1.0"?>
<Cursos>
<?php
	if(($_codigo == 1) || ($_codigo == -1)){
	
?>
	<Curso>
		<Codigo>1</Codigo>
		<Nome>Administração</Nome>
	</Curso>
<?php
	}
	if(($_codigo == 2) || ($_codigo == -1)){
?>
	<Curso>
		<Codigo>2</Codigo>
		<Nome>Moda<Nome>
	</Curso>
<?php
	}
	if(($_codigo == 3) || ($_codigo == -1)){
?>
	<Curso>
		<Codigo>3</Codigo>
		<Nome>Ciência da Computação</Nome>
	<Curso>
<?php 
	}
?>
</Cursos>	
	
	
